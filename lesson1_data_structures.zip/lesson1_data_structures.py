#Word length:
a = 'Word_length'
length = len(a)

print(length)

#Sums and differences:
first = 10
second = 15

sum = first + second
diff = first - second

print(sum, diff)

#Average:
first = 10
second = 15
third = 2

mean = (first + second + third) / 3

print(mean)

#Simple strings:
first_string = 'Вторник'
second_string = 'Понедельник'

print(second_string + ", " + first_string)

#Complex formula:
a = 10
b = -5
c = 2

f = ((a * b) + (a * c)) ** 3

print(f / 2)
